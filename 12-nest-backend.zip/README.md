# Backend en Nest

```
docker compose up -d
```

Copiar el ```.env.template``` y renombrarlo a ```.env```



